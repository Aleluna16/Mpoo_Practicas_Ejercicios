# Proyecto de Nomina

## Descripcion
Programa de consola en Java que calcula la nomina de empleados por sueldo fijo,
por horas y por comision. Incluye validacion de datos y manejo de excepciones.

## Organizacion
- `src/Modelo`: clases del dominio (`Empleado` y sus tipos concretos).
- `src/Excepciones`: excepciones personalizadas.
- `src/Principal`: clase `Main` con los casos de prueba y ejecucion.

## Tecnologia utilizada
- **Java SE (API estandar de Java):** se utilizan clases y funcionalidades incluidas
  en el JDK, ademas de las clases propias del proyecto.
- **No se utiliza una API web ni servicios externos.**
- **No se utiliza Maven ni Gradle:** el proyecto no necesita dependencias externas.
  Para este proyecto academico es suficiente compilar con `javac` y ejecutar con `java`.
  Si posteriormente se agregan bibliotecas externas, se puede incorporar Maven o Gradle.

## Requisitos
JDK 8 o posterior.

## Compilar y ejecutar
Desde la carpeta `NominaProyecto`:

```bash
mkdir -p build
javac -d build src/Excepciones/*.java src/Modelo/*.java src/Principal/*.java
java -cp build Principal.Main
```

## Casos de prueba
- CP-01: empleado Ana con sueldo fijo de $12,000. Resultado: $12,000.
- CP-02: empleado por horas, 170 horas a $100. Resultado: $18,000
  (160 horas normales y 10 horas al doble).
- CP-03: empleado por horas, 350 horas. Resultado: se lanza `NominaException`
  porque el maximo permitido es 300 horas.

## Reglas de calculo
- Por sueldo: se paga el sueldo mensual registrado.
- Por horas: hasta 160 horas se paga tarifa normal; de 161 a 300,
  las horas adicionales se pagan al doble.
- Comisionista: sueldo base mas 8% de las ventas.

## Excepciones
- `DatoInvalidoException`: se utiliza para rechazar datos invalidos al crear empleados.
- `NominaException`: se utiliza cuando no se puede calcular un pago, como cuando
  las horas trabajadas estan fuera del rango permitido.
